This folder contains the dataset of the AILA Track organized in FIRE 2019.

The first 10 queries, that is, queries from AILA_Q1 to AILA_Q10 was provided as a training set to the partcipants.
The remaining 40 queries, that is, queries from AILA_Q11 to AILA_Q50 was used for evaluation.

Description of the folders :

1. dataset.zip : Please read the README.txt file for detailed information.

2. train-data-rel-judgement : The details are provided in the "Trainingdata+RunSubmGuidelines.pdf" file in this folder.

3. test-data-rel-judgment : contains the relevance judgment of the remaining 40 queries. Data format is same as (2).
